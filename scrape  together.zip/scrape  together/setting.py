import tkinter as tk
from tkinter import messagebox
import openpyxl

def open_excel(license_plate):
    try:
        # 尝试打开Excel文件，如果不存在则创建一个新的Excel文件
        try:
            wb = openpyxl.load_workbook('C:/Users/Frank/Desktop/20003170107徐国庆/20003170107徐国庆-项目代码/datafile/vip.xlsx')
        except FileNotFoundError:
            wb = openpyxl.Workbook()
            wb.active.title = "License Plates"
            wb.save('C:/Users/Frank/Desktop/20003170107徐国庆/20003170107徐国庆-项目代码/datafile/vip.xlsx')

        sheet = wb.active

        # 读取车牌号
        license_plates = [cell.value for cell in sheet['A']]

        # 检查车牌号是否存在
        if not license_plates:
            messagebox.showinfo("车牌号信息", "没有车牌号可展示！")
        else:
            # 创建新窗口来显示所有车牌号
            new_window = tk.Toplevel()
            new_window.title("所有车牌号")

            # 创建文本框来展示车牌号
            text_widget = tk.Text(new_window)
            text_widget.pack()

            # 在文本框中插入所有车牌号
            for plate in license_plates:
                if plate is not None:
                    text_widget.insert(tk.END, plate + "\n")

    except Exception as e:
        messagebox.showerror("错误", str(e))

def open_new_window(root, license_plate):
    new_window = tk.Toplevel(root)
    new_window.title(license_plate)
    new_button = tk.Button(new_window, text="打开Excel", command=lambda: open_excel(license_plate))
    new_button.pack()




